import React from 'react'

const FileTable = () => {
  return (
    <div>FileTable</div>
  )
}

export default FileTable